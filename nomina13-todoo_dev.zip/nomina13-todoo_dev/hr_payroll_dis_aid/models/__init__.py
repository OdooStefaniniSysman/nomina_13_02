from . import hr_payroll_dis_aid
from . import res_partner
from . import hr_employee
from . import hr_payroll_debt_capacity
from . import inherited_hr_payslip
from . import inherited_hr_salary_rule
