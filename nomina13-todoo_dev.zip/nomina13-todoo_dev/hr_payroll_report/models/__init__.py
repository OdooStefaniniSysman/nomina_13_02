# Copyright 2020-TODAY Miguel Pardo <ing.miguel.pardo@gmail.com>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import hr_risk_type
from . import inherited_hr_contract
from . import inherited_hr_employee
from . import hr_contributor_type
from . import inherited_res_partner
from . import inherited_res_city
from . import inherited_res_company
from . import hr_payroll_pila
from . import hr_payslip
