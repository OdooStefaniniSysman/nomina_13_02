from . import inherited_hr_employee
from . import inherited_res_company
