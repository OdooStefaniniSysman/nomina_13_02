# -*- coding: utf-8 -*-
# Copyright 2020-TODAY Miguel Pardo <ing.miguel.pardo@gmail.com>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import hr_center_formation
from . import hr_marital_status
from . import hr_contract_alert
from . import hr_contract_type
from . import hr_contract_reason_change
from . import inherited_hr_employee
from . import inherited_hr_contract
from . import inherited_res_company
from . import inherited_hr_job
