# -*- coding: utf-8 -*-
# Copyright 2020-TODAY Miguel Pardo <ing.miguel.pardo@gmail.com>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import inherited_hr_payslip_employees
from . import payroll_config_reason_reject
from . import reprocess_acumulate_wizard
from . import hr_payroll_generate_send_wizard
from . import cesantia_found_wizard
