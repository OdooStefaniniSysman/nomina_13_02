# -*- coding: utf-8 -*-
# Copyright 2020-TODAY Miguel Pardo <ing.miguel.pardo@gmail.com>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import hr_leave
from . import hr_leave_code
from . import hr_pv
from . import inherited_hr_contract
from . import hr_employee
from . import inherit_hr_job
from . import inherited_hr_payslip
from . import inherited_hr_salary_rule
from . import hr_assigment_employee
