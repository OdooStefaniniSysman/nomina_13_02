from . import hr_employee_substitution
from . import hr_request_news
#from . import new_fields_todoo
