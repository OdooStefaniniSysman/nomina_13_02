# -*- coding: utf-8 -*-
# Copyright 2020-TODAY Miguel Pardo <ing.miguel.pardo@gmail.com>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import hr_contract_completion
from . import inherited_hr_payslip
from . import inherited_hr_pv
from . import inherited_hr_contract
