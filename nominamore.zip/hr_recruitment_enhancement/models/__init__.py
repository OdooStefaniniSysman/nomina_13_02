# -*- coding: utf-8 -*-

from . import hr_recruitment
from . import hr_employee
# from . import hr_job
