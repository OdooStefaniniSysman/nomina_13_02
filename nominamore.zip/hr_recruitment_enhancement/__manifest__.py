# -*- coding: utf-8 -*-
{
    'name': 'Recruitment Enhancement',
    'version': '13.0.1.0.0',
    'author': 'MPTechnolabs',
    'depends': [
        'hr_recruitment',
    ],
    'summary': 'Recruitment Enhancement',
    'website': 'http://www.mptechnolabs.com',
    'data': [
        'views/hr_employee.xml',
    ],
    'installable': True,
    'auto_install': False,
}
