# -*- coding: utf-8 -*-
# Copyright 2020-TODAY Miguel Pardo <ing.miguel.pardo@gmail.com>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).


from . import hr_payslip_iw_recalc
from . import inherited_hr_employee
from . import inherited_hr_value_uvt
from . import inherited_hr_payslip
