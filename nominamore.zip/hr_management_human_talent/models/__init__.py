from . import hr_request_new
from . import hr_employee
from . import hr_labor_relation
from . import hr_contract
from . import analytic_account
from . import salary_increase
from . import fields_todoo
