# -*- coding: utf-8 -*-
# Copyright 2020-TODAY Miguel Pardo <ing.miguel.pardo@gmail.com>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

# from . import hr_leaves_generate
from . import hr_payroll_config
from . import hr_payroll_config_parameters
from . import inherited_hr_salary_rule
from . import inherited_res_partner
from . import inherited_res_bank
from . import inherited_hr_employee
from . import inherited_hr_contract
from . import inherited_hr_leave_type
from . import inherited_resource_calendar
from . import inherited_hr_payslip
from . import hr_acumulated_rules
from . import hr_conf_acumulated
from . import hr_employee_acumulate
from . import hr_payslip
#from . import l10n_latam_identification_type
